'use client'

import Image from 'next/image'
import { Download } from 'lucide-react'
import type { AppEntry } from '@/lib/apps'

export function AppCard({ app }: { app: AppEntry }) {
  function triggerDownload() {
    // Redirect the browser to the APK download URL.
    window.open(app.downloadUrl, '_blank', 'noopener,noreferrer')
  }

  return (
    <article
      onClick={triggerDownload}
      className="group relative flex cursor-pointer flex-col rounded-2xl border border-border bg-card p-6 transition-all duration-300 hover:-translate-y-1 hover:border-neon-blue/50 hover:shadow-[0_0_40px_-12px] hover:shadow-neon-blue/40"
    >
      {/* subtle gradient ring on hover */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 rounded-2xl bg-gradient-to-br from-neon-blue/0 to-neon-purple/0 opacity-0 transition-opacity duration-300 group-hover:from-neon-blue/5 group-hover:to-neon-purple/10 group-hover:opacity-100"
      />

      <div className="relative flex items-center gap-4">
        <div className="relative size-16 shrink-0 overflow-hidden rounded-2xl border border-border shadow-lg">
          <Image
            src={app.icon || '/placeholder.svg'}
            alt={`${app.title} app icon`}
            fill
            sizes="64px"
            className="object-cover"
          />
        </div>
        <div className="min-w-0">
          <h3 className="truncate font-mono text-lg font-semibold tracking-tight">{app.title}</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            v{app.version} · {app.size}
          </p>
        </div>
      </div>

      <p className="relative mt-4 flex-1 text-pretty text-sm leading-relaxed text-muted-foreground">
        {app.description}
      </p>

      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation()
          triggerDownload()
        }}
        className="relative mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-neon-blue to-neon-purple px-4 py-3 text-sm font-semibold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neon-blue focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        aria-label={`Download ${app.title} APK`}
      >
        <Download className="size-4" aria-hidden="true" />
        Download APK
      </button>
    </article>
  )
}
