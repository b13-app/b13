import { Smartphone, Zap } from 'lucide-react'

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      {/* ambient neon glows */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-32 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-neon-blue/20 blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-10 right-1/4 h-64 w-64 rounded-full bg-neon-purple/20 blur-3xl"
      />

      <div className="relative mx-auto flex max-w-6xl flex-col items-center px-6 pt-24 pb-16 text-center sm:pt-32">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-4 py-1.5 text-sm text-muted-foreground backdrop-blur">
          <Zap className="size-4 text-neon-blue" aria-hidden="true" />
          Fresh builds, straight from the source
        </div>

        <h1 className="text-balance text-4xl font-semibold tracking-tight sm:text-6xl">
          Welcome to{' '}
          <span className="bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
            b13 App Store
          </span>
        </h1>

        <p className="mt-6 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
          Download my latest Android creations directly.
        </p>

        <div className="mt-8 flex items-center gap-2 text-sm text-muted-foreground">
          <Smartphone className="size-4 text-neon-purple" aria-hidden="true" />
          <span>APK downloads · No account required · Always up to date</span>
        </div>
      </div>
    </section>
  )
}
