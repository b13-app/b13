import { apps } from '@/lib/apps'
import { AppCard } from '@/components/app-card'

export function AppGrid() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-12" aria-labelledby="apps-heading">
      <div className="mb-8 flex items-end justify-between gap-4">
        <div>
          <h2 id="apps-heading" className="text-2xl font-semibold tracking-tight sm:text-3xl">
            Latest apps
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            {apps.length} apps ready to install on your device.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {apps.map((app) => (
          <AppCard key={app.id} app={app} />
        ))}
      </div>
    </section>
  )
}
