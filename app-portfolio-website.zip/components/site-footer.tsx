export function SiteFooter() {
  return (
    <footer className="mt-8 border-t border-border">
      <div className="mx-auto max-w-6xl px-6 py-8 text-center text-sm text-muted-foreground">
        © 2026 b13. All rights reserved.
      </div>
    </footer>
  )
}
