import { Hero } from '@/components/hero'
import { AppGrid } from '@/components/app-grid'
import { SiteFooter } from '@/components/site-footer'

export default function Page() {
  return (
    <main className="min-h-dvh">
      <Hero />
      <AppGrid />
      <SiteFooter />
    </main>
  )
}
