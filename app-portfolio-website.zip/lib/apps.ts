export type AppEntry = {
  id: string
  title: string
  description: string
  icon: string
  version: string
  size: string
  downloadUrl: string
}

// Replace downloadUrl with your real APK links (e.g. a direct file or release page).
export const apps: AppEntry[] = [
  {
    id: 'shop-list',
    title: 'SHOP LIST',
    description:
      'A lightning-fast shopping list that syncs your items, aisles, and budgets so you never forget the essentials again.',
    icon: '/icons/shop-list.png',
    version: '2.4.1',
    size: '8.2 MB',
    downloadUrl: '#',
  },
  {
    id: 'zinou',
    title: 'ZINOU',
    description:
      'Your personal productivity companion — track habits, set goals, and stay focused with a clean, distraction-free flow.',
    icon: '/icons/zinou.png',
    version: '1.9.0',
    size: '11.5 MB',
    downloadUrl: '#',
  },
  {
    id: 'quicknotes',
    title: 'QUICKNOTES',
    description:
      'Capture ideas the instant they strike. Rich notes, tags, and offline-first storage that stays out of your way.',
    icon: '/icons/notes.png',
    version: '3.1.2',
    size: '6.7 MB',
    downloadUrl: '#',
  },
  {
    id: 'skycast',
    title: 'SKYCAST',
    description:
      'Hyper-local weather with hourly precision, severe alerts, and a beautiful glanceable forecast for the week ahead.',
    icon: '/icons/weather.png',
    version: '4.0.3',
    size: '14.1 MB',
    downloadUrl: '#',
  },
  {
    id: 'pulsefit',
    title: 'PULSEFIT',
    description:
      'Track workouts, steps, and heart rate with smart insights that adapt to your routine and keep you moving.',
    icon: '/icons/fit.png',
    version: '2.0.0',
    size: '18.9 MB',
    downloadUrl: '#',
  },
  {
    id: 'coinwallet',
    title: 'COINWALLET',
    description:
      'Take control of your money with effortless expense tracking, budgets, and clear monthly spending breakdowns.',
    icon: '/icons/wallet.png',
    version: '1.5.4',
    size: '9.8 MB',
    downloadUrl: '#',
  },
]
